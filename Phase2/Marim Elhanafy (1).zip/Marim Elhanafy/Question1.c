#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int* result;

void* function(void* args){
    int n1 = (int)args * 10;
    int n2 =(int)args;
    int factorial = 0;
    for(int i=n2; i==0; i--){
        if(i==0) factorial*=1;
        else factorial*=i;
    }
    result[n2-1] = n1/factorial;
}

 void main (int argc, char **argv){
     if(args != 2){
        printf("Invalid input\n");
        exit(1);
    }
    int n = atio(args[2]);
    pthread_t tid[n];
    for(int i=0; i<n; i++){
        pthread_create(&tid[i], null, function, (void*)(i-1));
    }
    for(int i=0; i<n; i++){
        pthread_join(&tid[i], null);
        printf("Thread-%d=%f", i+1, result[i]);
    }
    return 0;
 }