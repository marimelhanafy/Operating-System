import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	ServerSocket server;
	

	public Server(int port) throws Exception {
		server = new ServerSocket(port);
		Socket client = server.accept();
		Service serviceObj = new Service(client);
		serviceObj.run();
	}

	
	
	public static void main(String[] args) throws Exception {
		new Server(1342);
	}

}
