import java.net.Socket;
import java.util.Formatter;
import java.util.Scanner;

public class Service extends Thread {

	Socket serv;

	public Service(Socket serv) {
		super();
		this.serv = serv;
	}
	
	public void run(){
		Scanner fromServer = null;
		Formatter toServer = null;
		
		try{
			fromServer = new Scanner(serv.getInputStream());
			toServer = new Formatter(serv.getOutputStream());
			
			int N = fromServer.nextInt();
			int X = fromServer.nextInt();
			double result = 0;
			for (int i = 1; i<=N; i+=2){
				int fact = 0;
				for (int j=i; j==0; j--){//factorial
					if (j==0){
						fact*=1;
					}
					else
						fact *=j;
				}
				result += (X+N)^(i)/fact;
			}
			toServer.format("%.2f", result);

		}
		catch(Exception ioe){
			ioe.printStackTrace();
		}
		finally{
			try{
				if(toServer != null)
					toServer.close();
				if(fromServer != null)
					fromServer.close();
				if(serv != null)
					serv.close();
			}
			catch(Exception ioe){
				ioe.printStackTrace();
			}
		}
	}
}
