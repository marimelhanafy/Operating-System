import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

		int N, X;
		double temp;
		
		Socket s = new Socket("localhost", 1342);
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter N to send to Server: ");
		N = sc.nextInt();
		System.out.print("Enter X to send to Server: ");
		X = sc.nextInt();
		
		PrintStream p = new PrintStream(s.getOutputStream());
		p.println(N);
		p.println(X);
		
		Scanner sc1 = new Scanner(s.getInputStream());
		temp = sc1.nextFloat();
		System.out.println("The Result from Server S=" + temp);
		
		s.close();
		
	}

}
