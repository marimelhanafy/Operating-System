#!/bin/bash

FirstSub(){
	while(true)
	do{
		echo "-----------Menu----------"
		echo "enter number of:"
		echo "1 File"
		echo "2 Directory"
		echo "q to quit"
		input = read  "Enter your choice: "
		if (input == 1){
			type = file input
			if(-size 0M input)
			if(type == "java"){
					if()
			}
		}
		if (input == 2){
			find ~ -size 3K> input
		}
		if (input == q){
			fi;
		}
	}
	
	
		
	
}

SecondSub(){
mkdir "$private"

cc -pthread

}
FirstSub
SecondSub
